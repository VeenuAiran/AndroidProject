package com.example.androidproject_cmpe277;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

public class MainActivity extends FragmentActivity implements LocationListener
{
	 private static final long MINIMUM_DISTANCECHANGE_FOR_UPDATE = 1; // in Meters
     private static final long MINIMUM_TIME_BETWEEN_UPDATE = 1000; // in Milliseconds
     private static final long POINT_RADIUS = 100; // in Meters
     private static final long PROX_ALERT_EXPIRATION = -1; // It will never expire
     private static final String PROX_ALERT_INTENT = "com.example.AndroidProject-CMPE277.ProximityIntentReceiver";
	private int width, height;
	private GoogleMap map;
	private SupportMapFragment fragment;
	Button navigation,btGo,notify;
	TextView tvMyLocation;
	private LatLngBounds latlngBounds;
	private static LatLng Origin = new LatLng(0.0,0.0);
	double X_Origin,Y_Origin,X_Dest,Y_Dest;
	private static LatLng Destination = new LatLng(0.0,0.0);
	
	private Polyline newPolyline;
	private Geocoder geocoder;
	EditText et;
	private LocationManager locationManager;
	private String provider;

	Address add;

	List<Address> addresses = null;
	String MyLocation;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		et = (EditText)findViewById(R.id.dest);
		btGo =(Button)findViewById(R.id.go);
		notify = (Button)findViewById(R.id.Notify);
		navigation = (Button)findViewById(R.id.bNavigation);
		tvMyLocation =(TextView)findViewById(R.id.TextView02);
		geocoder = new Geocoder(getApplicationContext(),Locale.getDefault());
	    // Get the location manager
	    locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
	    // Define the criteria how to select the locatioin provider -> use
	    // default
	    Criteria criteria = new Criteria();
	    provider = locationManager.getBestProvider(criteria, false);
	    Location location = locationManager.getLastKnownLocation(provider);
	    if (location != null) {
	        System.out.println("Provider " + provider + " has been selected.");
	        onLocationChanged(location);
	      } else 
	      {
	    	  Log.d("Location ","Null");
	      }
	 
		fragment = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map));
		map = fragment.getMap(); 
		map.getUiSettings().setMyLocationButtonEnabled(true);
		
		getSreenDimanstions();
		
		notify.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) 
			{
				// TODO Auto-generated method stub
				addProximityAlert();
				
			}	
			
		});
		  
	    btGo.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) 
			{
				 String destination = et.getText().toString();
				// TODO Auto-generated method stub
				 Log.d("Destination Text",destination);
				
				Log.d("Origin Lat", Double.toString(X_Origin));
				Log.d("Orirgin latitude", Double.toString(Y_Origin));
				Origin = new LatLng(X_Origin,Y_Origin);
				geocode(destination);
				Destination = new LatLng(X_Dest,Y_Dest);	
				
			}

			
			private void geocode(String destination) 
			{
				// TODO Auto-generated method stub
				 
		    	  try {
		    		  addresses = geocoder.getFromLocationName(destination, 1);
						add = addresses.get(0);
						X_Dest = add.getLatitude();
						Y_Dest = add.getLongitude();
						
						} catch (IOException e)
						{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}	
	    });
	    	
	navigation.setOnClickListener(new View.OnClickListener() 
	{
			
		
			@Override
			public void onClick(View v) {
				
				System.out.println(X_Origin + "Origin LAt");
				System.out.println(Y_Origin + "Origin Lon");
				System.out.println(Y_Dest + "Dest LAt");
				System.out.println(Y_Dest + "Dest LAt");
				System.out.println(Origin);
				System.out.println(Destination);
			findDirections( Origin.latitude, Origin.longitude,Destination.latitude, Destination.longitude, Parser.MODE_DRIVING );
		
			}
			});
		
	}

	private void addProximityAlert() 
	{
		// TODO Auto-generated method stub
		  Intent intent = new Intent(PROX_ALERT_INTENT);
          PendingIntent proximityIntent = PendingIntent.getBroadcast(this, 0, intent, 0);
          locationManager.addProximityAlert(
                 Destination.latitude, 
                 Destination.longitude,
                 POINT_RADIUS, 
                 PROX_ALERT_EXPIRATION,                         
                 proximityIntent);

          IntentFilter filter = new IntentFilter(PROX_ALERT_INTENT);
          registerReceiver(new ProximityIntentReceiver(), filter);
          Toast.makeText(getApplicationContext(),"Notification is Added",Toast.LENGTH_SHORT).show();
	}
	public void handleGetDirectionsResult(ArrayList<LatLng> directionPoints) {
		PolylineOptions rectLine = new PolylineOptions().width(5).color(Color.RED);

		for(int i = 0 ; i < directionPoints.size() ; i++) 
		{          
			rectLine.add(directionPoints.get(i));
		}
		if (newPolyline != null)
		{
			newPolyline.remove();
		}
		newPolyline = map.addPolyline(rectLine);
	
		latlngBounds = createLatLngBoundsObject(Origin, Destination);
	    map.animateCamera(CameraUpdateFactory.newLatLngBounds(latlngBounds, width, height, 150));
	    map.addMarker(new MarkerOptions().position(Destination).title("POI"));
	    map.addMarker(new MarkerOptions().position(Origin).title("YOU ARE HERE!"));
		
	}
	
	private LatLngBounds createLatLngBoundsObject(LatLng origin2,LatLng destination2) 
	{
		// TODO Auto-generated method stub
		if (origin2 != null && destination2 != null)
		{
			LatLngBounds.Builder builder = new LatLngBounds.Builder();    
			builder.include(origin2).include(destination2);
			
			return builder.build();
		}
		return  null;
	}
	

	public void findDirections(double fromPositionDoubleLat, double fromPositionDoubleLong, double toPositionDoubleLat, double toPositionDoubleLong, String mode)
	{
		Map<String, String> map = new HashMap<String, String>();
		map.put(DirectionAsyncTask.CURRENT_LAT, String.valueOf(fromPositionDoubleLat));
		map.put(DirectionAsyncTask.USER_CURRENT_LONG, String.valueOf(fromPositionDoubleLong));
		map.put(DirectionAsyncTask.DESTINATION_LAT, String.valueOf(toPositionDoubleLat));
		map.put(DirectionAsyncTask.DESTINATION_LONG, String.valueOf(toPositionDoubleLong));
		map.put(DirectionAsyncTask.DIRECTIONS_MODE, mode);
		
		DirectionAsyncTask asyncTask = new DirectionAsyncTask(this);
		asyncTask.execute(map);	
	}
	private void getSreenDimanstions()
	{
		Display display = getWindowManager().getDefaultDisplay();
		width = display.getWidth(); 
		height = display.getHeight(); 
			
	
	}
	@Override
	protected void onResume() {
		
		super.onResume();
    	latlngBounds = createLatLngBoundsObject(Origin , Destination);
        map.moveCamera(CameraUpdateFactory.newLatLngBounds(latlngBounds, width, height, 150));
        locationManager.requestLocationUpdates(provider, 500, 1, this);
	}

	 

	  /* Remove the locationlistener updates when Activity is paused */
	  @Override
	  protected void onPause() {
	    super.onPause();
	    locationManager.removeUpdates(this);
	  }
	

	@Override
	public void onLocationChanged(Location location) 
	{
		// TODO Auto-generated method stub
		X_Origin = location.getLatitude();
	    Y_Origin = location.getLongitude();
	    tvMyLocation.setText(Double.toString(X_Origin));
	    tvMyLocation.append(Double.toString(Y_Origin));  
	}

	@Override
	public void onProviderDisabled(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onProviderEnabled(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
		// TODO Auto-generated method stub
		
	}
		
	}

